export const API_HOST = "http://localhost:8080/api/";
